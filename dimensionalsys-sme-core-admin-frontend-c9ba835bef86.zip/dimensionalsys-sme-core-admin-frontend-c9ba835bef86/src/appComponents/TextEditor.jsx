import React from 'react'

const TextEditor = () => {
  return (
    <div>TextEditor</div>
  )
}

export default TextEditor