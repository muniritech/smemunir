import React,{useEffect} from 'react'
import TextEditor from '../TextEditor'





const TextEditorModal = () => {
    

  return (
    <div className="bg-white w-[80%] h-[90%] px-4 py-4 rounded-md flex flex-col gap-5">TextEditorModal
    
    <TextEditor/>
    </div>
  )
}

export default TextEditorModal