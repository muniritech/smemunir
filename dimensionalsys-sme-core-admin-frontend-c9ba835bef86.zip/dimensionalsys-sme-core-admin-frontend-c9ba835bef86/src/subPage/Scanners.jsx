import React from "react";

const Scanners = () => {
  return <div>Scanners</div>;
};

export default Scanners;
