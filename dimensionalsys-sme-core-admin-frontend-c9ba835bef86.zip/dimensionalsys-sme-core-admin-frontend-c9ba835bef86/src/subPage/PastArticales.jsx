import React from 'react'

const PastArticales = () => {
  return (
    <div>PastArticales</div>
  )
}

export default PastArticales